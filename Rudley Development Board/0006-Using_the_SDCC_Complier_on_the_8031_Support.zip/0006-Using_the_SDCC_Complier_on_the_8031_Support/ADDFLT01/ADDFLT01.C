#include <8051.h>
 
 float var1 = 5;
 float var2 = 6;
 float var3 = 7;
 
 void main(void)
{
	while (1)
	{
	var3 = var1 + var2;
	}
}